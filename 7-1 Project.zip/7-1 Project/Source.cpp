#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#include <chrono>
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "Camera.h"

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    float PI = 3.14159265359;
    float toRadians = (PI / 180);
    const char* const WINDOW_TITLE = "7-1 Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao[6];         // Handle for the vertex array object
        GLuint vbos[6];     // Handles for the vertex buffer objects
        GLuint nVertices[6];    // Number of indices of the mesh
        GLsizei nIndices[6];
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    // Texture id
    GLuint gTextureIdWhite;
    GLuint gTextureIdSilver;
    GLuint gTextureIdBlack;
    GLuint gTextureIdCards;
    GLuint gTextureIdSpray;
    GLuint gTextureIdCableH;
    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_REPEAT;
    // Shader program
    GLuint gProgramId;
    GLuint gLampProgramId;

    // Light: color, position, object, and scale
    glm::vec3 gObjectColor(1.0f, 1.0f, 1.0f); // white
    glm::vec3 gLightColor(1.0f, 1.0f, 1.0f); // white
    glm::vec3 gcubeLightColor(1.0f, 1.0f, 1.0f);
    glm::vec3 gcubeLightPosition(2.3f, 0.0f, 0.6f);
    glm::vec3 gLightPosition(2.5f, 6.5f, 3.5f); // above plane-center/right
    glm::vec3 gLightScale(0.5f);

    // camera
    Camera gCamera(glm::vec3(0.467021f, -24.7183f, -4.02682f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    bool isPerspective = true;
    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char*
    fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
std::chrono::steady_clock::time_point gLastPrintTime;
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);


const char* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);

//Fragment Shader Source Code
const GLchar* fragmentShaderSource = GLSL(440,
    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.5f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.8f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);

/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j) {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;
        for (int i = width * channels; i > 0; --i) {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Load texture
// Load texture
    const char* sphereFilename = "../Textures/white.jpeg";
    const char* torusFilename = "../Textures/silver.jpg";
    const char* planeFilename = "../Textures/black.jpg";
    const char* cardsFilename = "../Textures/Card.jpg";
    const char* sprayFilename = "../Textures/Spray.jpg";
    const char* cableholderFilename = "../Textures/CH.jpg";
    if (!UCreateTexture(sphereFilename, gTextureIdWhite)) {
        cout << "Failed to load texture " << sphereFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(torusFilename, gTextureIdSilver)) {
        cout << "Failed to load texture " << torusFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(planeFilename, gTextureIdBlack)) {
        cout << "Failed to load texture " << planeFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(cardsFilename, gTextureIdCards)) {
        cout << "Failed to load texture " << cardsFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(sprayFilename, gTextureIdSpray)) {
        cout << "Failed to load texture " << sprayFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(cableholderFilename, gTextureIdCableH)) {
        cout << "Failed to load texture " << cableholderFilename << endl;
        return EXIT_FAILURE;
    }

    glUseProgram(gProgramId); // tell opengl for each sampler to which texture unit it belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0); // We set the texture as texture unit 0

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
   // ----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // -------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // ----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureIdWhite);
    UDestroyTexture(gTextureIdSilver);
    UDestroyTexture(gTextureIdBlack);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    gLastPrintTime = std::chrono::steady_clock::now();


#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        isPerspective = !isPerspective;
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// ------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
 // ---------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
 // -------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);
    // Clear the frame and z buffers
    glClearColor(0.46f, 0.46f, 0.46f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();
    // Creates a projection THEN create perspective or orthographic view
    glm::mat4 projection;

    // NOW check if 'isPerspective' and THEN set the perspective
    if (isPerspective) {
        projection = glm::perspective(glm::radians(gCamera.Zoom),
            (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else {
        float scale = 90;
        projection = glm::ortho((800.0f / scale), -(800.0f / scale), -(600.0f /
            scale), (600.0f / scale), -2.5f, 6.5f);
    }

    // Plane 
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    glm::mat4 model = translation * rotation * scale;
    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");
    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y,
        gLightPosition.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y,
        cameraPosition.z);
    // Pass data to cube light
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gcubeLightColor.r, gcubeLightColor.g,
        gcubeLightColor.b);
    glUniform3f(lightPositionLoc, gcubeLightPosition.x, gcubeLightPosition.y,
        gcubeLightPosition.z);
    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao[0]);
    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdBlack);
    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[0]);
    // Bottle object
    scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    rotation = glm::rotate(2.0f * (toRadians), glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(2.6f, 1.0f, 1.0f));
    model = translation * rotation * scale;
    modelLoc = glGetUniformLocation(gProgramId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    //Activate the VBOs
    glBindVertexArray(gMesh.vao[1]);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdSpray);
    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[1]);
    // Magic Cards
    scale = glm::scale(glm::vec3(2.5f, 0.5f, 1.0f));
    rotation = glm::rotate(75.0f * (toRadians), glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.0f, 0.0f, 1.7f));
    model = translation * rotation * scale;
    modelLoc = glGetUniformLocation(gProgramId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    //Activate the VBOs
    glBindVertexArray(gMesh.vao[2]);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdCards);
    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[2]);
    // Torus
    scale = glm::scale(glm::vec3(0.2f, 0.2f, 0.2f));
    rotation = glm::rotate(25.0f * (toRadians), glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.5f, 0.0f, -1.0f));
    model = translation * rotation * scale;
    modelLoc = glGetUniformLocation(gProgramId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    //Activate the VBOs
    glBindVertexArray(gMesh.vao[3]);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdSilver);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices[3], GL_UNSIGNED_INT, 0);
    // Sphere
    scale = glm::scale(glm::vec3(0.2f, 0.2f, 0.2f));
    rotation = glm::rotate(25.0f * (toRadians), glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.5f, 0.0f, -1.0f));
    model = translation * rotation * scale;
    modelLoc = glGetUniformLocation(gProgramId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    //Activate the VBOs
    glBindVertexArray(gMesh.vao[4]);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdWhite);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices[4], GL_UNSIGNED_INT, 0);
    // Cable Holder
    scale = glm::scale(glm::vec3(0.3f, 0.05f, 0.3f));
    rotation = glm::rotate(90.0f * (toRadians), glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(0.85f, 0.0f, -0.5f));
    model = translation * rotation * scale;
    modelLoc = glGetUniformLocation(gProgramId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    //Activate the VBOs
    glBindVertexArray(gMesh.vao[5]);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdCableH);
    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[5]);
    // LAMP: draw light
    glUseProgram(gLampProgramId);
    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLightPosition) * glm::scale(gLightScale);
    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");
    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[5]);
    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    glfwSwapBuffers(gWindow); // Flips the the back buffer with the front buffer every frame.
}


void UCreateMesh(GLMesh& mesh) {


    // Vertex data
    GLfloat planeVerts[] = {
        // Vertex Positions  // Normals        // Texture
        -5.0f, -0.1f,  5.0f,   0.0f, 1.0f, 0.0f,  0.0f, 0.0f,
        5.0f, -0.1f, -5.0f,   0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
        -5.0f, -0.1f, -5.0f,   0.0f, 1.0f, 0.0f,  0.0f, 1.0f,

        -5.0f, -0.1f,  5.0f,   0.0f, 1.0f, 0.0f,  0.0f, 0.0f,
        5.0f, -0.1f, -5.0f,   0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
        5.0f, -0.1f,  5.0f,   0.0f, 1.0f, 0.0f,  1.0f, 0.0f,
    };

    // Vertex data for cylinder
    const int numCylinderSegments = 1000; // Reduced number of segments
    const float cylinderRadius = 0.4f;
    const float cylinderHeight = 2.0f;

    const int numCylinderVerts = (numCylinderSegments + 1) * 2 + numCylinderSegments * 2; // + numCylinderSegments for each circle
    const int cylinderVertexSize = 8; // 3 for position, 3 for normal, 2 for texture

    GLfloat* cylinderVerts = new GLfloat[numCylinderVerts * cylinderVertexSize];

    int cylinderVertIndex = 0;

    // Generate vertices for the side surface of the cylinder
    for (int i = 0; i <= numCylinderSegments; ++i) {
        float theta = static_cast<float>(i) / static_cast<float>(numCylinderSegments) * glm::two_pi<float>();
        float x = cylinderRadius * cos(theta);
        float z = cylinderRadius * sin(theta);

        // Bottom vertex
        cylinderVerts[cylinderVertIndex++] = x;
        cylinderVerts[cylinderVertIndex++] = -cylinderHeight / 2.0f;
        cylinderVerts[cylinderVertIndex++] = z;

        // Normal
        cylinderVerts[cylinderVertIndex++] = x / cylinderRadius; // Normals should be based on vertex position
        cylinderVerts[cylinderVertIndex++] = 0.0f;
        cylinderVerts[cylinderVertIndex++] = z / cylinderRadius;

        // Texture coordinates
        cylinderVerts[cylinderVertIndex++] = static_cast<float>(i) / static_cast<float>(numCylinderSegments);
        cylinderVerts[cylinderVertIndex++] = 0.0f;

        // Top vertex
        cylinderVerts[cylinderVertIndex++] = x;
        cylinderVerts[cylinderVertIndex++] = cylinderHeight / 2.0f;
        cylinderVerts[cylinderVertIndex++] = z;

        // Normal
        cylinderVerts[cylinderVertIndex++] = x / cylinderRadius; // Normals should be based on vertex position
        cylinderVerts[cylinderVertIndex++] = 0.0f;
        cylinderVerts[cylinderVertIndex++] = z / cylinderRadius;

        // Texture coordinates
        cylinderVerts[cylinderVertIndex++] = static_cast<float>(i) / static_cast<float>(numCylinderSegments);
        cylinderVerts[cylinderVertIndex++] = 1.0f;
    }

    // Generate vertices for the bottom circle
    for (int i = 0; i < numCylinderSegments; ++i) {
        float theta = static_cast<float>(i) / static_cast<float>(numCylinderSegments) * glm::two_pi<float>();
        float x = cylinderRadius * cos(theta);
        float z = cylinderRadius * sin(theta);

        // Bottom vertex
        cylinderVerts[cylinderVertIndex++] = x;
        cylinderVerts[cylinderVertIndex++] = -cylinderHeight / 2.0f;
        cylinderVerts[cylinderVertIndex++] = z;

        // Normal (straight down)
        cylinderVerts[cylinderVertIndex++] = 0.0f;
        cylinderVerts[cylinderVertIndex++] = -1.0f;
        cylinderVerts[cylinderVertIndex++] = 0.0f;

        // Texture coordinates (optional for the bottom)
        cylinderVerts[cylinderVertIndex++] = x / cylinderRadius * 0.5f + 0.5f;
        cylinderVerts[cylinderVertIndex++] = z / cylinderRadius * 0.5f + 0.5f;
    }

    // Indices for connecting the top circle with triangles
    std::vector<GLuint> topCircleIndices;
    for (int i = 0; i < numCylinderSegments; ++i) {
        topCircleIndices.push_back(numCylinderSegments * 2 + i);
        topCircleIndices.push_back(numCylinderSegments * 2 + (i + 1) % numCylinderSegments);
        topCircleIndices.push_back(numCylinderSegments * 3 + i);
    }

    // Indices for connecting the bottom circle with triangles
    std::vector<GLuint> bottomCircleIndices;
    for (int i = 0; i < numCylinderSegments; ++i) {
        bottomCircleIndices.push_back(numCylinderSegments * 4 + i);
        bottomCircleIndices.push_back(numCylinderSegments * 4 + (i + 1) % numCylinderSegments);
        bottomCircleIndices.push_back(numCylinderSegments * 5 + i);
    }
    GLfloat cardVerts[] = {
        // Vertex Positions     // Normals           // Texture 
        // Base (Facing Y-)
        -0.5f, 0.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
         0.5f, 0.0f,  0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,
         0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
        -0.5f, 0.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
        -0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,
         0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
         // Top (Facing Y+)
         -0.5f,  3.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
          0.5f,  3.0f,  0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,
          0.5f,  3.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
         -0.5f,  3.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
         -0.5f,  3.0f, -0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,
          0.5f,  3.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
          // Side #1 (Facing Z-)
          -0.5f, 0.0f,  0.5f,   0.0f,  0.0f, 1.0f,  0.0f, 0.0f,
           0.5f, 0.0f,  0.5f,   0.0f,  0.0f, 1.0f,  1.0f, 0.0f,
           0.5f,  3.0f,  0.5f,   0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
          -0.5f, 0.0f,  0.5f,   0.0f,  0.0f, 1.0f,  0.0f, 0.0f,
          -0.5f,  3.0f,  0.5f,   0.0f,  0.0f, 1.0f,   0.0f, 1.0f,
           0.5f,  3.0f,  0.5f,   0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
           // Side #2 (Facing X+)
            0.5f, 0.0f,  0.5f,   1.0f, 0.0f, 0.0f,    0.0f, 0.0f,
            0.5f, 0.0f, -0.5f,   1.0f, 0.0f, 0.0f,    1.0f, 0.0f,
            0.5f,  3.0f, -0.5f,   1.0f, 0.0f, 0.0f,    1.0f, 1.0f,
            0.5f, 0.0f,  0.5f,   1.0f, 0.0f, 0.0f,    0.0f, 0.0f,
            0.5f,  3.0f,  0.5f,   1.0f, 0.0f, 0.0f,    0.0f, 1.0f,
            0.5f,  3.0f, -0.5f,   1.0f, 0.0f, 0.0f,    1.0f, 1.0f,
            // Side #3 (Facing Z+)
            -0.5f, 0.0f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 0.0f,
             0.5f, 0.0f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 0.0f,
             0.5f,  3.0f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 1.0f,
            -0.5f, 0.0f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 0.0f,
            -0.5f,  3.0f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 1.0f,
             0.5f,  3.0f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 1.0f,
             // Side #4 (Facing X-)
             -0.5f, 0.0f,  0.5f,  -1.0f, 0.0f, 0.0f,   0.0f, 0.0f,
             -0.5f, 0.0f, -0.5f,  -1.0f, 0.0f, 0.0f,   1.0f, 0.0f,
             -0.5f,  3.0f, -0.5f,  -1.0f, 0.0f, 0.0f,   1.0f, 1.0f,
             -0.5f, 0.0f,  0.5f,  -1.0f, 0.0f, 0.0f,   0.0f, 0.0f,
             -0.5f,  3.0f,  0.5f,  -1.0f, 0.0f, 0.0f,   0.0f, 1.0f,
             -0.5f,  3.0f, -0.5f,  -1.0f, 0.0f, 0.0f,   1.0f, 1.0f
    };
    const int numTorusSegments = 30;
    const int numTorusRings = 14;
    const float torusRadius = 1.5f;
    const float tubeRadius = 0.2f;

    // Calculate torus vertices with normals and indices
    const int numTorusVerts = (numTorusRings + 1) * (numTorusSegments + 1);
    const int torusVertexSize = 6; // 3 for position, 3 for normal
    GLfloat* torusVerts = new GLfloat[numTorusVerts * torusVertexSize];
    GLuint* torusIndices = new GLuint[numTorusRings * numTorusSegments * 6];

    int torusVertIndex = 0;
    for (int ring = 0; ring <= numTorusRings; ++ring) {
        float phi = 2.0f * glm::pi<float>() * static_cast<float>(ring) / static_cast<float>(numTorusRings);
        float sinPhi = sin(phi);
        float cosPhi = cos(phi);

        for (int segment = 0; segment <= numTorusSegments; ++segment) {
            float theta = 2.0f * glm::pi<float>() * static_cast<float>(segment) / static_cast<float>(numTorusSegments);
            float sinTheta = sin(theta);
            float cosTheta = cos(theta);

            float x = (torusRadius + tubeRadius * cosTheta) * cosPhi;
            float z = (torusRadius + tubeRadius * cosTheta) * sinPhi;
            float y = tubeRadius * sinTheta * 0.6f;

            glm::vec3 vertex(x, y, z);
            glm::vec3 center(torusRadius * cosPhi, 0.0f, torusRadius * sinPhi);
            glm::vec3 normal = glm::normalize(vertex - center);

            // Set vertex position
            torusVerts[torusVertIndex++] = x;
            torusVerts[torusVertIndex++] = y;
            torusVerts[torusVertIndex++] = z;

            // Set vertex normal
            torusVerts[torusVertIndex++] = normal.x;
            torusVerts[torusVertIndex++] = normal.y;
            torusVerts[torusVertIndex++] = normal.z;


        }
        int torusIndexIndex = 0;
        for (int ring = 0; ring < numTorusRings; ++ring) {
            for (int segment = 0; segment < numTorusSegments; ++segment) {
                int nextRing = (ring + 1) % numTorusRings;
                int nextSegment = (segment + 1) % numTorusSegments;

                // First triangle
                torusIndices[torusIndexIndex++] = (ring * (numTorusSegments + 1)) + segment;
                torusIndices[torusIndexIndex++] = (nextRing * (numTorusSegments + 1)) + segment;
                torusIndices[torusIndexIndex++] = (ring * (numTorusSegments + 1)) + nextSegment;

                // Second triangle
                torusIndices[torusIndexIndex++] = (ring * (numTorusSegments + 1)) + nextSegment;
                torusIndices[torusIndexIndex++] = (nextRing * (numTorusSegments + 1)) + segment;
                torusIndices[torusIndexIndex++] = (nextRing * (numTorusSegments + 1)) + nextSegment;
            }
        }

    }

    const int numSphereSegments = 14;
    const int numSphereRings = 6;
    const float sphereRadius = 1.3f;

    // Calculate sphere vertices with normals and indices
    const int numSphereVerts = (numSphereRings + 1) * (numSphereSegments + 1);
    const int sphereVertexSize = 6; // 3 for position, 3 for normal
    GLfloat* sphereVerts = new GLfloat[numSphereVerts * sphereVertexSize];
    GLuint* sphereIndices = new GLuint[numSphereRings * numSphereSegments * 6];

    int sphereVertIndex = 0;
    for (int ring = 0; ring <= numSphereRings; ++ring) {
        float phi = glm::pi<float>() * static_cast<float>(ring) / static_cast<float>(numSphereRings);
        float sinPhi = sin(phi);
        float cosPhi = cos(phi);

        for (int segment = 0; segment <= numSphereSegments; ++segment) {
            float theta = 2.0f * glm::pi<float>() * static_cast<float>(segment) / static_cast<float>(numSphereSegments);
            float sinTheta = sin(theta);
            float cosTheta = cos(theta);

            float x = sphereRadius * cosTheta * sinPhi;
            float y = sphereRadius * cosPhi * 0.6f;
            float z = sphereRadius * sinTheta * sinPhi;

            glm::vec3 vertex(x, y, z);
            glm::vec3 normal = glm::normalize(vertex);

            // Set vertex position
            sphereVerts[sphereVertIndex++] = x;
            sphereVerts[sphereVertIndex++] = y;
            sphereVerts[sphereVertIndex++] = z;

            // Set vertex normal
            sphereVerts[sphereVertIndex++] = normal.x;
            sphereVerts[sphereVertIndex++] = normal.y;
            sphereVerts[sphereVertIndex++] = normal.z;

        }
        int sphereIndexIndex = 0;
        for (int ring = 0; ring < numSphereRings; ++ring) {
            for (int segment = 0; segment < numSphereSegments; ++segment) {
                int nextRing = ring + 1;
                int nextSegment = (segment + 1) % numSphereSegments;

                // First triangle
                sphereIndices[sphereIndexIndex++] = (ring * (numSphereSegments + 1)) + segment;
                sphereIndices[sphereIndexIndex++] = (nextRing * (numSphereSegments + 1)) + segment;
                sphereIndices[sphereIndexIndex++] = (ring * (numSphereSegments + 1)) + nextSegment;

                // Second triangle
                sphereIndices[sphereIndexIndex++] = (ring * (numSphereSegments + 1)) + nextSegment;
                sphereIndices[sphereIndexIndex++] = (nextRing * (numSphereSegments + 1)) + segment;
                sphereIndices[sphereIndexIndex++] = (nextRing * (numSphereSegments + 1)) + nextSegment;
            }
        }

    }


    GLfloat cubeVerts[] = {
        // Vertex Positions     // Normals           // Texture 
        // Base (Facing Y-)
        -0.5f, 0.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
         0.5f, 0.0f,  0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,
         0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
        -0.5f, 0.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
        -0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,
         0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
         // Top (Facing Y+)
         -0.5f,  3.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
          0.5f,  3.0f,  0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,
          0.5f,  3.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
         -0.5f,  3.0f,  0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f,
         -0.5f,  3.0f, -0.5f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,
          0.5f,  3.0f, -0.5f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,
          // Side #1 (Facing Z-)
          -0.5f, 0.0f,  0.5f,   0.0f,  0.0f, 1.0f,  0.0f, 0.0f,
           0.5f, 0.0f,  0.5f,   0.0f,  0.0f, 1.0f,  1.0f, 0.0f,
           0.5f,  3.0f,  0.5f,   0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
          -0.5f, 0.0f,  0.5f,   0.0f,  0.0f, 1.0f,  0.0f, 0.0f,
          -0.5f,  3.0f,  0.5f,   0.0f,  0.0f, 1.0f,   0.0f, 1.0f,
           0.5f,  3.0f,  0.5f,   0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
           // Side #2 (Facing X+)
            0.5f, 0.0f,  0.5f,   1.0f, 0.0f, 0.0f,    0.0f, 0.0f,
            0.5f, 0.0f, -0.5f,   1.0f, 0.0f, 0.0f,    1.0f, 0.0f,
            0.5f,  3.0f, -0.5f,   1.0f, 0.0f, 0.0f,    1.0f, 1.0f,
            0.5f, 0.0f,  0.5f,   1.0f, 0.0f, 0.0f,    0.0f, 0.0f,
            0.5f,  3.0f,  0.5f,   1.0f, 0.0f, 0.0f,    0.0f, 1.0f,
            0.5f,  3.0f, -0.5f,   1.0f, 0.0f, 0.0f,    1.0f, 1.0f,
            // Side #3 (Facing Z+)
            -0.5f, 0.0f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 0.0f,
             0.5f, 0.0f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 0.0f,
             0.5f,  3.0f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 1.0f,
            -0.5f, 0.0f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 0.0f,
            -0.5f,  3.0f, -0.5f,   0.0f, 0.0f, -1.0f,   0.0f, 1.0f,
             0.5f,  3.0f, -0.5f,   0.0f, 0.0f, -1.0f,   1.0f, 1.0f,
             // Side #4 (Facing X-)
             -0.5f, 0.0f,  0.5f,  -1.0f, 0.0f, 0.0f,   0.0f, 0.0f,
             -0.5f, 0.0f, -0.5f,  -1.0f, 0.0f, 0.0f,   1.0f, 0.0f,
             -0.5f,  3.0f, -0.5f,  -1.0f, 0.0f, 0.0f,   1.0f, 1.0f,
             -0.5f, 0.0f,  0.5f,  -1.0f, 0.0f, 0.0f,   0.0f, 0.0f,
             -0.5f,  3.0f,  0.5f,  -1.0f, 0.0f, 0.0f,   0.0f, 1.0f,
             -0.5f,  3.0f, -0.5f,  -1.0f, 0.0f, 0.0f,   1.0f, 1.0f
    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;
    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal +
        floatsPerUV);
    mesh.nVertices[0] = sizeof(planeVerts) / (sizeof(planeVerts[0]) *
        (floatsPerVertex + floatsPerNormal + floatsPerUV));
    mesh.nVertices[1] = numCylinderVerts * (floatsPerVertex + floatsPerNormal + floatsPerUV);
    mesh.nVertices[2] = sizeof(cardVerts) / (sizeof(cardVerts[0]) *
        (floatsPerVertex + floatsPerNormal + floatsPerUV));
    mesh.nIndices[3] = numTorusRings * numTorusSegments * 6; // 6 indices per quad (2 triangles per quad)
    mesh.nIndices[4] = numSphereRings * numSphereSegments * 6; // Similarly, 6 indices per quad    
    mesh.nVertices[5] = sizeof(cubeVerts) / (sizeof(cubeVerts[0]) *
        (floatsPerVertex + floatsPerNormal + floatsPerUV));
    // Plane Mesh
    glGenVertexArrays(1, &mesh.vao[0]); // we can also generate multiple VAOs or buffers at the same time
    glGenBuffers(1, &mesh.vbos[0]);
    glBindVertexArray(mesh.vao[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVerts), planeVerts,
        GL_STATIC_DRAW); // Sends vertex or coordinate data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)
        (sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)
        (sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
    // Bottle Mesh
    glGenVertexArrays(1, &mesh.vao[1]); // we can also generate multiple VAOs or buffers at the same time
    glGenBuffers(1, &mesh.vbos[1]);
    glBindVertexArray(mesh.vao[1]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[1]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * numCylinderVerts * cylinderVertexSize, cylinderVerts, GL_STATIC_DRAW);
    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, cylinderVertexSize * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    // Normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, cylinderVertexSize * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, cylinderVertexSize * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    // Magic Card Mesh
    glGenVertexArrays(1, &mesh.vao[2]); // we can also generate multiple VAOs or buffers at the same time
    glGenBuffers(1, &mesh.vbos[2]);
    glBindVertexArray(mesh.vao[2]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[2]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(cardVerts), cardVerts,
        GL_STATIC_DRAW); // Sends vertex or coordinate data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)
        (sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)
        (sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
    // Adjustments for Torus Mesh
    glGenVertexArrays(1, &mesh.vao[3]);
    glGenBuffers(1, &mesh.vbos[3]);
    GLuint torusEBO;
    glGenBuffers(1, &torusEBO); // Generate EBO for torus indices

    glBindVertexArray(mesh.vao[3]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[3]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * numTorusVerts * torusVertexSize, torusVerts, GL_STATIC_DRAW);

    // Position attribute for the torus
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, torusVertexSize * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    // Normal attribute for the torus
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, torusVertexSize * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Bind EBO and upload the torus indices data
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, torusEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, numTorusRings * numTorusSegments * 6 * sizeof(GLuint), torusIndices, GL_STATIC_DRAW);

    // Adjustments for Sphere Mesh
    glGenVertexArrays(1, &mesh.vao[4]);
    glGenBuffers(1, &mesh.vbos[4]);
    GLuint sphereEBO;
    glGenBuffers(1, &sphereEBO); // Generate EBO for sphere indices

    glBindVertexArray(mesh.vao[4]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[4]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * numSphereVerts * sphereVertexSize, sphereVerts, GL_STATIC_DRAW);

    // Position attribute for the sphere
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sphereVertexSize * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    // Normal attribute for the sphere
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sphereVertexSize * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Bind EBO and upload the sphere indices data
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, numSphereRings * numSphereSegments * 6 * sizeof(GLuint), sphereIndices, GL_STATIC_DRAW);
    //Cable Holder Mesh
    glGenVertexArrays(1, &mesh.vao[5]); // we can also generate multiple VAOs or buffers at the same time
    glGenBuffers(1, &mesh.vbos[5]);
    glBindVertexArray(mesh.vao[5]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[5]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVerts), cubeVerts,
        GL_STATIC_DRAW); // Sends vertex or coordinate data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)
        (sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)
        (sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    // Don't forget to delete dynamically allocated arrays
    delete[] torusVerts;
    delete[] torusIndices;
    delete[] sphereVerts;
    delete[] sphereIndices;
    delete[] cylinderVerts;
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(4, mesh.vao);
    glDeleteBuffers(4, mesh.vbos);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}